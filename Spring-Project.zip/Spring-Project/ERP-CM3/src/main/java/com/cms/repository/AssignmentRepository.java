package com.cms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cms.entity.Assignment;


public interface AssignmentRepository extends JpaRepository<Assignment, Integer>{

}
