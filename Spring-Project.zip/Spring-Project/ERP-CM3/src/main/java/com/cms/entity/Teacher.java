package com.cms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "teachers")
public class Teacher {
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne
	@JoinColumn(name = "teacher_id")
	private Student teacher;
	
	@Column(name = "email", length = 40)
	private String email;
	
	@Column(name = "phone", nullable = false, length = 10)
	private String phone;
	
	
	public Teacher() {
		// TODO Auto-generated constructor stub
	}


	public Teacher(Long id, Student teacher, String email, String phone) {
		super();
		this.id = id;
		this.teacher = teacher;
		this.email = email;
		this.phone = phone;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public Student getTeacher() {
		return teacher;
	}


	public void setTeacher(Student teacher) {
		this.teacher = teacher;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	

}
