package com.cms.service;


import java.util.List;


import com.cms.entity.Timetable;

public interface TimetableService {

	
	void addTimetable(Timetable timetable);
	
	List<Timetable> getTimetable();
}
