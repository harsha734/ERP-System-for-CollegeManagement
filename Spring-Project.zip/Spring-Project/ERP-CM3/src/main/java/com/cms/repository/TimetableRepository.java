package com.cms.repository;

import org.springframework.data.repository.CrudRepository;

import com.cms.entity.Timetable;

public interface TimetableRepository extends CrudRepository<Timetable, Integer>{

}
