

package com.cms.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cms.entity.Timetable;
import com.cms.repository.TimetableRepository;

@Service
@Transactional
public class TimetableServiceimpl  implements TimetableService{

	
	private final TimetableRepository timetableRepository;

	
	public TimetableServiceimpl(TimetableRepository timetableRepository){
		this.timetableRepository = timetableRepository ; 
	}
	
	@Override
	public void addTimetable(Timetable timetable) {
		timetableRepository.save(timetable);
		
	}

	public List<Timetable> getTimetable() {
		List<Timetable> schedules= new ArrayList<>();
		timetableRepository.findAll().forEach(schedules::add);
		return schedules;
	}

	
}
