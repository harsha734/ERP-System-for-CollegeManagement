package com.cms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.cms.entity.Assignment;

import com.cms.service.AssignmentService;


@Controller
public class AssignmentController {

    @Autowired AssignmentService assignmentService;	
	
    //add Student Assignment
	public Assignment addStudent(Assignment assignment) {
		return assignmentService.addStudentAss(assignment);
	}
}
